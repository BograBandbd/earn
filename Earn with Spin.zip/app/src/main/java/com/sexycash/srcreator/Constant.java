package com.sexycash.srcreator;

public class Constant<images> {



    private static final String MAIN_URL = "https://srcreator.xyz/test/android/";
    public static final String APP_API = "test";
    public static final String FACEBOOK_INTER_ADS_CODE = "";
    public static final String FACEBOOK_BANNER_ADS_CODE = "";
    public static final String ONESIGNAL_APP_ID = "4cf610e9-0bf7-4d73-8e2f-131a62d85a06";
    public static final String Dev_LInk = "https://t.me/srcreator";

    public static final String RATE_US = "https://play.google.com/store/apps/details?id=";
    public static final String UPDATE_LINK_URL = "https://play.google.com/store/apps/details?id=";
    public static final String VPN_URL = "https://play.google.com/store/apps/details?id=com.macomputertech.alvivpnunlimited";
    public static final String BINGO_VPN_URL = "https://play.google.com/store/apps/details?id=com.macomputertech.alvivpnunlimited";
    public static final String COUNT_URL_ADMIN = MAIN_URL+"admin_get_url.php";
    public static final String COUNT_URL_USER = MAIN_URL+"user_get_url.php";

    public static final String BANNER_LIST_URL = MAIN_URL+"banner_list.php";

    public static final String CHECK_LOGIN = MAIN_URL+"check_user.php";
    public static final String CHECK_SPLASH = MAIN_URL+"check_splash_user.php";
    public static final String USER_SIGNUP = MAIN_URL+"user_signup.php";
    public static final String REDEEM_AMOUNT_INSERT_URL = MAIN_URL+"withdraw_insert.php";
    public static final String VIDEO_IMP_POINT_ADD_URL = MAIN_URL+"user_video_imp_count_add.php";
    public static final String MATH_IMP_POINT_ADD_URL = MAIN_URL+"user_math_imp_count_add.php";
    public static final String SPIN_IMP_POINT_ADD_URL = MAIN_URL+"user_spin_imp_count_add.php";
    public static final String SRATCH_IMP_POINT_ADD_URL = MAIN_URL+"user_scratch_imp_count_add.php";
    public static final String DAILY_POINT_ADD_URL = MAIN_URL+"daily_point.php";
    public static final String WALLET_LIST_URL = MAIN_URL+"wallet_type_list.php";
    public static final String WALLET_LIST_HISTORY_URL = MAIN_URL+"wallet_history.php";
    public static final String BONUS_POINT_ADD_URL = MAIN_URL+"bonus_point.php";

    public static final String WATCH_TIME_ADD_URL = MAIN_URL+"watch_start.php";
    public static final String WATCH_TIME_GONE_URL = MAIN_URL+"watch_end.php";

    public static final String SPIN_TIME_ADD_URL = MAIN_URL+"spin_start.php";
    public static final String SPIN_TIME_GONE_URL = MAIN_URL+"spin_end.php";

    public static final String MATH_TIME_ADD_URL = MAIN_URL+"math_start.php";
    public static final String MATH_TIME_GONE_URL = MAIN_URL+"math_end.php";

    public static final String SCRATCH_TIME_ADD_URL = MAIN_URL+"scratch_start.php";
    public static final String SCRATCH_TIME_GONE_URL = MAIN_URL+"scratch_end.php";




    public static final String MESSAGE = "message";
    public static final String ERROR = "error";
    public static final String ACTION = "action";
    public static final String APP_UPDATE_TAG = "android_update";
    public static final String APP_API_TAG = "android_api";

    public static final String USERID_TAG = "android_id";
    public static final String NAME_TAG = "android_name";
    public static final String APP_EMAIL = "android_email";
    public static final String APP_PASSWORD = "android_password";
    public static final String APP_REFER = "android_refer";
    public static final String AMOUNT_TAG = "android_amount";
    public static final String MSG = "android_msg";
    public static final String METHOD_TAG = "android_method";
    public static final String NUMBER_TAG = "android_number";
    public static final String INFO_WITH ="android_with_info";

    public static final String VIDEO_IMP_COUNT_TAG = "android_video_imp";
    public static final String ADMIN_VIDEO_IMP_COUNT_TAG = "android_admin_video_imp";
    public static final String VIDEO_IMP_AMOUNT_TAG = "android_video_amount";

    public static final String MATH_IMP_COUNT_TAG = "android_math_imp";
    public static final String ADMIN_MATH_IMP_COUNT_TAG = "android_admin_math_imp";

    public static final String SPIN_IMP_COUNT_TAG = "android_spin_imp";
    public static final String ADMIN_SPIN_IMP_COUNT_TAG = "android_admin_spin_imp";

    public static final String USER_SCRATCH_IMP_COUNT_TAG = "android_scratch_imp";
    public static final String USER_ADMIN_SCRATCH_IMP_COUNT_TAG = "android_admin_scratch_imp";

    public static final String DAILY_AMOUNT_TAG = "android_daily_amount";
    public static final String BONUS_AMOUNT_TAG = "android_bonus_amount";

    public static final String ABOUT = "android_about";
    public static final String PRIVACY = "android_privacy";
    public static final String HOW = "android_how";
    public static final String TELEGRAM = "android_telegram";
    public static final String FACEBOOK = "android_facebook";

    public static final String VIDEO_CLICK_AMOUNT = "android_video_click";
    public static final String SCRATCH_CLICK_AMOUNT = "android_scratch_click";
    public static final String SPIN_CLICK_AMOUNT = "android_spin_click";
    public static final String GAME_CLICK_AMOUNT = "android_game_click";

    public static final String PAYMENT_IMAGE = "image";
    public static final String PAYMENT_MINIMUM = "minimum";
    public static final String PAYMENT_METHOD = "method";

    public static final String IMAGE = "image";
    public static final String TEXT = "text";


    public static final String STATUS = "android_status";
    public static final String DATE = "android_date";


    public static final String APP_COUNT = "android_count";
    public static final String INVITE = "android_invite";
    public static final String APP_IMIE = "android_imie";

    public static final String STARTAPP = "android_startapp";
    public static final String UNITY = "android_unity";

    public static final String BANNER = "android_banner";
    public static final String INTERSIAL = "android_intersial";
    public static final String VIDEO = "android_video";


    public static final String  SLIDER_PHOTO_TAG = "android_photo_url";

}
